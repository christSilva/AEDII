class Vertice {
    constructor(name) {
        this.name = name;
        this.edges = []
    }
    insert(dest, edge) {
        this.edges.push({
            dest: dest,
            edge: edge,
        })
    }
    haveDest(dest) {
        for(let e of this.edges) 
            if(e.dest === dest) return true;
        return false;
    }
    getName() {
        return this.name;
    }
    getEdges() {
        return this.edges;
    }
    getEdge(dest) {
        for(let e of this.edges) 
            if(e.dest === dest) return e.edge;
        return 0;
    }
}
module.exports = Vertice;