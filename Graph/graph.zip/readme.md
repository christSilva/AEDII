Please, run the follow commands in terminal:

$ npm i //to install dependencies

$ node main //to run the app